local discordia = require('discordia')
local client = discordia.Client()

return {
    name = "infract",
    description = "Direct Message",
    callback = function(message, args)
        if message.author.bot then return end

        -- Debugging: Print the received args
        print("Received args:", args and table.concat(args, ", ") or "nil")

        -- Ensure args is a table before checking its length
        if not args or type(args) ~= "table" or #args < 3 then
            return message:reply("Usage: !infract @user [reason] [punishment]")
        end

        -- Ensure a valid user is mentioned
        local user = message.mentionedUsers and message.mentionedUsers.first
        if not user then
            return message:reply("Please mention a valid user.")
        end

        -- Remove first two arguments (@user and first word after mention)
        table.remove(args, 1)

        -- Extract reason and punishment
        local reason, punishment = "No reason provided", "No punishment specified"
        local reasonEnd = false

        for _, word in ipairs(args) do
            if word:match("^%[.*%]$") then
                word = word:gsub("[%[%]]", "") -- Remove brackets
                if not reasonEnd then
                    reason = (reason ~= "No reason provided" and reason .. " " or "") .. word
                else
                    punishment = (punishment ~= "No punishment specified" and punishment .. " " or "") .. word
                end
            else
                reasonEnd = true
                punishment = (punishment ~= "No punishment specified" and punishment .. " " or "") .. word
            end
        end

        -- Debugging: Print extracted data
        print("User:", user.username)
        print("Reason:", reason)
        print("Punishment:", punishment)

        -- Create embed
        local embed = {
            title = "Infraction Issued",
            fields = {
                { name = "User", value = user.username or "Unknown", inline = true },
                { name = "Reason", value = reason, inline = true },
                { name = "Punishment", value = punishment, inline = false }
            },
            color = 0xFF0000,
            timestamp = discordia.Date():toISO()
        }

        -- Send embed message safely
        local success, err = pcall(function()
            message.channel:send({ embeds = { embed } })
        end)
        
        if not success then
            print("[ERROR] Failed to send message:", err)
        end
    end
}